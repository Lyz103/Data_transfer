import os
import sys
sys.path[0] = os.path.join(os.path.dirname(__file__), '..', '..')
from models.USER.CSHI.src.plugins import *
import os 
import pandas as pd
import json
from models.USER.CSHI.token_count_utils import count_token

class UserSimV3:
    def __init__(self, dataset_name='foodrec',model_name='gpt-3.5-turbo'):
        self.user_id = None
        self.target_item = None
        self.oai_messages = list()
        self.message = Message(content=None, message_type=None)
        self.message['dataset'] = dataset_name
        PluginManager().start(model_name=model_name)
    
    def reset(self, target_item: str, user_id: int):
        self.message['user_id'] = user_id
        self.message['target_items'] = [target_item]
        self.message['oai_messages'] = list()
        self.message['turn'] = 0
        self.message['content'] = target_item
        self.message['message_type'] = str
        # PluginManager().execute_stage("user_profile_init", self.message)
        PluginManager().execute_stage("real_time_preference_init", self.message)
    
    def step(self, response):
        self.oai_messages.append({"role": "user", "content": response})
        while count_token(self.oai_messages) > 10000:
            self.oai_messages = self.oai_messages[1:]
        self.message['content'] = response
        self.message['oai_messages'] = self.oai_messages
        PluginManager().execute_stage("handle_message", self.message)
        self.oai_messages.append({"role": "assistant", "content": self.message['reply']})
        self.message['turn'] += 1
        # print(self.message)
        return self.message['reply']

if __name__ == "__main__":
    openai.api_base = ""
    openai.api_key = ""
    user = UserSimV3()
    user.reset(target_item="Mapo toufu", user_id=1)
    reply = user.step("你好，有什么可以帮助你的吗？")
    while True:
        print(reply)
        response = input(">>>")
        reply = user.step(response)
        if reply == "对话结束":
            break