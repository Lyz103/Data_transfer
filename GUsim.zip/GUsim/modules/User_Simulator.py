import os
import sys
from typing import List, Dict, Tuple, Union, Callable
import re
import logging
from datetime import datetime
import time
sys.path[0] = os.path.join(os.path.dirname(__file__), '..')
from models.CRS.AgentCRS import AgentCRS
from models.CRS.GptBasedCRS import GptBasedCRS
sys.path[0] = os.path.join(os.path.dirname(__file__), '..')

from config.LLM_config import LLM_Model_Chat, LLM_Model_Action
# from modules.Memory.default_config.DefaultMemoryConfig import DEFAULT_FUMEMORY
from modules.Prompts import PromptTemplate
from config.Memory_config import DEFAULT_PROFILEMEMORY, DEFAULT_ACTIONMEMORY, DEFAULT_CHATMEMORY
from modules.Memory.config.Config import MemoryConfig
from modules.Memory import ChatMemory, ActionMemory, ProfileMemory
from utils import *
from modules.Prompts.prompts import *

# 创建 Logger 对象
LOGGER = logging.getLogger('my_logger')
LOGGER.setLevel(logging.DEBUG)  # 设置全局日志级别

# 控制台处理器
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.DEBUG)
console_formatter = logging.Formatter('%(levelname)s: %(message)s')
console_handler.setFormatter(console_formatter)

# 文件处理器
file_handler = logging.FileHandler('app.log')
file_handler.setLevel(logging.INFO)  # 仅记录错误及以上级别
file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(file_formatter)

# 添加两个处理器
LOGGER.addHandler(console_handler)
LOGGER.addHandler(file_handler)


# from Policy import LLM_Policy
class UserMemory:
    def __init__(self, profile):
        self.chat_memory_config = MemoryConfig(DEFAULT_CHATMEMORY)
        self.action_memory_config = MemoryConfig(DEFAULT_ACTIONMEMORY)
        self.profile_memory_config = MemoryConfig(DEFAULT_PROFILEMEMORY)
        self.chat_memory = ChatMemory(self.chat_memory_config)
        self.action_memory = ActionMemory(self.action_memory_config)
        self.profile_memory = ProfileMemory(self.profile_memory_config)
        self.profile_memory.store(profile)
    
    def recall(self) -> Union[str, str, str]:
        return self.profile_memory.recall(""), self.chat_memory.recall(""), self.action_memory.recall("")
    
    def _change_profile(self, new_profile) -> None:
        self.profile_memory.reset()
        self.profile.store(new_profile)
    
    def _store_action(self, action) -> None:
        self.action_memory.store(action)
    
    def _store_chat(self, chat_his) -> None:
        self.chat_memory.store(chat_his)
    
    def reset(self, new_profile) -> None:
        self.profile_memory.reset()
        self.profile_memory.store(new_profile)
        self.action_memory.reset()
        self.chat_memory.reset()

class UserAct:
        def __init__(self,
                 usermemory: UserMemory,
                 gen_action_llm: Callable,
                 gen_dialogue_llm: Callable,
                #  action_description_dir: str = None,
                #  action_space_prompt_dir: str = None,
                #  action_prompt_dir: str = None,
                #  action_incontext_dir: str = None,
                #  action_end_conversation_dir: str = None,
                #  response_prompt_dir: str = None,
                #  response_incontext_dir: str = None,
                #  reward_prompt_dir: str = None,
                #  reward_incontext_dir: str = None,
                #  reward_judge_dir: str = None,
                 ):
            
            self.gen_action_llm = gen_action_llm
            self.gen_dialogue_llm = gen_dialogue_llm
            self.user_memory = usermemory
        def _gen_actions(self, turn) -> Union[List, str, bool]:
            user_profile, his_chat, his_action = self.user_memory.recall()

            last_sys_output = re.split(r'\[turn \d+\]', his_chat)[-1]
            LOGGER.debug("last_sys_output: %s", last_sys_output)
            chat_action_his = put_action_chat_together(his_chat, his_action)

            user_profile = eval(user_profile)

            input_message = {}
            input_message.update(user_profile['basic_info'])
            input_message.update(user_profile['environment_info'])
            input_message.update(user_profile['preference'])
            print("input_message:", input_message)
            action_chara = user_profile['user_behavior']['action_chara']

            

            input = CRS_CHOOSE_ACTION.format(**input_message, chat_action_his=chat_action_his)
            LOGGER.debug("*" * 100)
            LOGGER.debug("input4action: %s", input)
            LOGGER.debug("*" * 100)

            actions_with_prob = self.gen_dialogue_llm(input)
            # print("actions_with_prob:", actions_with_prob)
            LOGGER.debug("actions_with_prob: %s", actions_with_prob)

            actions_with_prob_dict, reason, reflect = parse_actions(actions_with_prob)
            # print("5个动作:", actions_with_prob_dict)
            # print("原因:", reason)
            LOGGER.debug("5个动作: %s", actions_with_prob_dict)
            LOGGER.debug("原因: %s", reason)
            LOGGER.debug("反思: %s", reflect)


            sampled_action, sampled_reason = top_p_sample(actions_with_prob_dict, str(reason), p=0.4)
            # print("采样动作:", sampled_action)
            # if_end = self._judge_end(actions_with_prob_dict, sampled_action, his_action)
            # if end: if_end = True
            if turn >= 4:
                end_info = self.gen_dialogue_llm(JUDGE_END.format(**input_message, chat_action_his=sampled_action, action_chara=action_chara))
                LOGGER.debug(f"end_info :{end_info}")
                end_info = eval(end_info)
                if_end = "YES" in end_info['判断']
                LOGGER.debug(f"if_end :{if_end}")
            else:
                if_end = False
            LOGGER.debug("采样动作: %s", sampled_action)
            LOGGER.debug("采样原因: %s", sampled_reason)
            return sampled_action, sampled_reason, if_end



        def _gen_dialogue(self, turn) -> Union[str,bool]:
            # do not foget to add
            actions, reason, if_end = self._gen_actions(turn)
            if if_end: return None, True
            user_profile, his_chat, his_action = self.user_memory.recall()
            last_sys_output = re.split(r'\[turn \d+\]', his_chat)[-1]
            user_profile = eval(user_profile)
            words_chara = user_profile['user_behavior']['words_chara']
            chat_action_his = put_action_chat_together(his_chat, his_action)

            input_message = {}
            input_message.update(user_profile['basic_info'])
            input_message.update(user_profile['environment_info'])
            input_message.update(user_profile['preference'])
            print("input_message:", input_message)

            input = RESPONSE.format(**input_message, 
                                    chat_action_his=chat_action_his, 
                                    action_names=actions,
                                    inner_voice=reason, words_chara=words_chara)
            LOGGER.debug("*" * 100)
            LOGGER.debug("input4chat: %s", input)
            LOGGER.debug("*" * 100)

            dialogue_output = eval(self.gen_dialogue_llm(input))
            response = dialogue_output.get("回复", "")
            reasons = dialogue_output.get("原因", "")
            reflect = dialogue_output.get("反思", "")

            # print("response:", response)
            # print("reasons:", reasons)
            LOGGER.debug("reflect: %s", reflect)

            LOGGER.debug("response: %s", response)
            LOGGER.debug("reasons: %s", reasons)

            self._update_memory_User(actions, response)
            return response, if_end


        def _update_memory_User(self, actions, response) -> None:
            self.user_memory._store_action(str(actions))
            self.user_memory._store_chat(response)

        def _update_memory_Sys(self, response) -> None:
            self.user_memory._store_chat(response)
        



class UserSimulator:
    """
    User Simulator to simulate the user's behavior.
    """
    def __init__(self, profile: str, config=None, llm_action=None, llm_chat=None) -> None:
        self.memory = UserMemory(profile)
        # self.policy = LLM_Policy(config)
        self.llm_action = llm_action
        self.llm_chat = llm_chat
        self.name = "OurUser"  + self.llm_action.llm_model + self.llm_chat.llm_model
        self.UserAct = UserAct(self.memory, self.llm_action, self.llm_chat)


    def interact(self, turn) -> str:
        return self.UserAct._gen_dialogue(turn)
    
    def _update_memory(self, response):
        self.memory._store_chat(response)
        
    # def store(self, observation_chat, observation_act) -> None:
    #     self.chat_memory.store(observation_chat)
    #     self.action_memory.store(observation_act)
    
    # def recall(self, query) -> str:
    #     return self.chat_memory.recall(query)
    
    # def display(self) -> None:
    #     self.chat_memory.display()
    
    # def manage(self, operation, **kwargs) -> None:
    #     self.chat_memory.manage(operation, **kwargs)
    #     self.action_memory.manage(operation, **kwargs)
    
    # def optimize(self, **kwargs) -> None:
    #     self.chat_memory.optimize(**kwargs)
    #     self.action_memory.optimize(**kwargs)
    def refresh_profile(self) -> None:
        import json
        import random
        profiles = []
        with open("../modules/rec_profile.jsonl", 'r') as f:
            for line in f:
                profiles.append(str(line))
        self.memory.reset(random.choice(profiles))

    def __str__(self) -> str:
        return "User Simulator"
    
    def __repr__(self) -> str:
        return "User Simulator"
        # OUTPUT: SimulatedUserAct, str:

    def __call__(self, turn: int = 0) \
            -> str:
        """
        Simulate the user behavior based on the user input.
        :param crs_input: for the first turn, the crs_input can be None, otherwise, it should be the crs response
        :return: the user action(name, description), the user response(str) and the reward(int) to the crs
        """
        a = self.interact(turn)
        time.sleep(0.3)
        return a


if __name__ == "__main__":
    profiles = []
    with open("rec_profile.jsonl", 'r') as f:
        for line in f:
            profiles.append(str(line))
    for profile in profiles[100:150]:
        num = 0
        today = datetime.now()
        tody = today.strftime("%Y%m%d")
        file_dir = f"/data/liyuanzi/HUAWEI/User_simulator/GUsim/data/{tody}"
        os.makedirs(file_dir, exist_ok=True)
        files_dir = os.listdir(file_dir)
        while f"4omini_{num}.txt" in files_dir:
            num += 1
        file_path = os.path.join(file_dir, f"4omini_{num}.txt")

        with open(file_path, 'w', encoding='utf-8') as f:

            crs = GptBasedCRS(model="gpt-4o-mini")
            usersimulator = UserSimulator(profile, llm_action=LLM_Model_Action, llm_chat=LLM_Model_Chat)
            print("\n" * 10)
            f.write("用户资料:"  + str(profile) + '\n\n\n\n')

            for turn in range(5):
                user_chat, if_end = usersimulator.interact(turn)
                print("turn_" + str(turn + 1) + "    User: ", user_chat)
                f.write("[turn_" + str(turn + 1) + "]User: " +  ("None" if user_chat == None else user_chat) +  '\n\n\n\n')
                # print("crs.crs_agent.oai_messages：", crs.crs_agent.oai_messages)
                if if_end:
                    print("turn:", turn + 1)
                    print("\n" * 10)
                    break
                sys_chat = crs.interact(user_chat)
                usersimulator._update_memory(sys_chat)
                print("Sys:", sys_chat )
                f.write("[turn_" + str(turn + 1) + "]Sys:" + sys_chat + '\n\n\n\n')

    print("Finish!")
        

            # usersimulator.memory._store_chat("hello")
            # usersimulator.memory._store_chat("how are you")
            # usersimulator.memory._store_chat("how are you")
            # usersimulator.memory._store_chat("how are you")
            # usersimulator.memory._store_chat("how are you")
            # usersimulator.memory._store_chat("how are you")
            # usersimulator.memory._store_chat("how are you")
            # usersimulator.memory._store_chat("how are you")
            # usersimulator.memory._store_chat("how are ou")
            # usersimulator.memory._store_action("(action1)")
            # usersimulator.memory._store_action("(action1)")
            # usersimulator.memory._store_action("(action1)")
            # usersimulator.memory._store_action("(action1)")