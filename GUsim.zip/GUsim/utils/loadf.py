import re
import json
import random
from typing import Dict, List, Tuple
def load_file(path: str) -> str:
    with open(path, "r") as f:
        return f.read()


def load_file_utf8(path: str) -> str:
    with open(path, "r", encoding='utf-8') as f:
        return f.read()



def parse_actions(action_str):
    data = json.loads(action_str)  # 解析 JSON 字符串
    action_text = data.get("动作", "")  # 获取 "动作" 对应的字符串
    reason = data.get("原因", "")  # 获取 "原因"
    reflect = data.get("反思", "")
    pattern = r'([\w\u4e00-\u9fff]+):\s*(\d+)'  # 修改正则，避免匹配到括号
    pattern = r'[\[|\{]?\s*[\'\"]?([\w\u4e00-\u9fff]+)[\'\"]?:\s*(\d+)\s*[\]|\}]?'  
    matches = re.findall(pattern, action_text)
    actions = {action: int(score) for action, score in matches}
    return actions, reason, reflect


# def top_p_sample(action_dict, reason, p=0.4):
#     if(len(action_dict)==0): return []
#     sorted_actions = sorted(action_dict.items(), key=lambda x: x[1], reverse=True)
#     total_score = sum(action_dict.values())
#     cumulative_score = 0
#     selected_actions = []
    
#     for action, score in sorted_actions:
#         cumulative_score += score
#         selected_actions.append((action, score))
#         if cumulative_score >= total_score * p:
#             break
    
#     samlpe_actions, weights = zip(*selected_actions)
#     # return random.choices(actions, weights=weights, k=1)[0]
#     sample_reasons = reason[1:-1].split(";")
#     sample_reasons = sample_reasons[:len(samlpe_actions)]
#     return samlpe_actions, sample_reasons


def top_p_sample(action_dict: Dict[str, float], reason: str, p: float = 0.4) -> Tuple[List[str], List[str]]:
    """
    根据给定的动作字典和概率阈值 p，选择累积概率达到 p 的动作，并返回对应的动作列表和原因列表。

    参数:
        action_dict (Dict[str, float]): 动作及其对应的分数（权重）。
        reason (str): 原因字符串，格式为 "[reason1;reason2;...]"。
        p (float): 累积概率阈值，默认值为 0.4。

    返回:
        Tuple[List[str], List[str]]: 
            - 第一个元素是按累积概率选择的动作名称列表。
            - 第二个元素是与动作数量对应的原因列表。
    """
    # 检查输入字典是否为空
    if not action_dict:
        return [], []

    # 按分数从高到低排序动作字典
    sorted_actions: List[Tuple[str, float]] = sorted(
        action_dict.items(), key=lambda x: x[1], reverse=True
    )

    total_score: float = sum(action_dict.values())  # 计算总分
    cumulative_score: float = 0.0
    selected_actions: List[Tuple[str, float]] = []

    # 遍历排序后的动作，直到累积概率达到阈值 p
    for action, score in sorted_actions:
        cumulative_score += score
        selected_actions.append((action, score))
        if cumulative_score >= total_score * p:
            break

    # 提取选中的动作名称和对应的权重
    sampled_actions, weights = zip(*selected_actions)

    # 解析原因字符串并截取与动作数量对应的部分
    parsed_reasons: List[str] = reason.strip("[]").split(";")
    sampled_reasons: List[str] = parsed_reasons[:len(sampled_actions)]

    return list(sampled_actions), sampled_reasons




def put_action_chat_together(chat_his, action_his):
    res = ""
    # print("chat_his:", chat_his)
    turns_chat = re.findall(r'(\[turn \d+\][^\[]+)', chat_his.strip(), re.DOTALL)
    turns_chat = [turn.strip() for turn in turns_chat]
    # print("turns_chat:", turns_chat)
    turns_action = action_his.strip().split("\n")
    turns_chat_user = turns_chat[::2]
    turns_chat_sys = turns_chat[1::2]
    if len(turns_chat) == 0:
        return None
    for turn_action, turn_chat_user, turn_chat_sys in zip(turns_action, turns_chat_user, turns_chat_sys):
        # print("turn_action:", turn_action)
        # print("turn_chat_user:", turn_chat_user)
        # print("turn_chat_sys:", turn_chat_sys)

        match = re.match(r"\[turn (\d+)\]\s*(.*)", turn_action)
        turn_number, text = match.groups()
        res += (turn_chat_user + ' ' + text + '\n' + turn_chat_sys + '\n')
    # print("res:", res)
    return res
