import openai
import json
from openai import OpenAI
import os
os.environ["OPENAI_BASE_URL"] = "https://api.chatanywhere.tech"

os.environ["OPENAI_API_KEY"] = "sk-G6XflAR04SvxaTl1QhmIl6HimueZ0ZPYFeEVD78gELMRqth5"
client = OpenAI()

prompt = """你是一个语义分析专家，给定两轮对话中的句子，请判断它们的含义是否一致或相似。具体来说，你需要判断两个句子的意思是否相同或接近。请按照以下要求作答：
1. 请判断这两个句子的含义是否一致或相似。
2. 你需要回复“是”或“否”，并给出解释。
以下是你要分析的两个句子：
句子1：{sentence1}
句子2：{sentence2}
请严格遵循以下JSON格式进行回答：
{{
  "is_same": "是/否",
  "explanation": "解释你判断的原因",
  "sentence1": "第一个句子的内容",
  "sentence2": "第二个句子的内容",
}}
"""

def check_semantic_similarity(sentence1, sentence2):
    """
    使用GPT-4判断两个句子是否具有相同语义
    :param sentence1: 第一个句子
    :param sentence2: 第二个句子
    :return: 布尔值（True/False）表示是否同义
    """
    try:
        # 构建系统提示和用户查询
        prompt_t = prompt.format(sentence1=sentence1, sentence2=sentence2)
        messages = [
            {"role": "user", "content": prompt_t}
        ]

        # 调用GPT-4 API
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.1,  # 降低温度值获得更稳定的结果
            max_tokens=500
        )

        # 解析响应内容
        content = response.choices[0].message.content
        content = eval(content)
        print(content)
        # print(content["sentence1"], content["sentence2"])
        # print(content["is_same"], content["explanation"])
        if content["is_same"] == "是":
            return True
        else:
            return False

        

    except Exception as e:
        print(f"发生错误：{str(e)}")
        return None



tot = 100
t = 0
count = 0
with open("history_5.jsonl", 'r') as f:
    for line in f:
        count += 1
        if count > tot:
            break
        data = json.loads(line)
        turns_user = []
        for i in range(2, 6):
            turn2 = "turn_" + str(i)
            turn1 = "turn_" + str(i-1)
            try:
                sentence_a = data[turn1]["user"]
                sentence_b = data[turn2]["user"]
                print(sentence_a==sentence_b)
                # if check_semantic_similarity(sentence_a, sentence_b):
                #     t += 1
                #     break
                if sentence_b == sentence_a:
                    print(sentence_a, sentence_b)
                    t += 1
                    continue
            except:
                continue
print(t)
print(t / tot)