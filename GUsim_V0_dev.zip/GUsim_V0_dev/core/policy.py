# core/policy.py
from abc import ABC, abstractmethod
from typing import Dict, Any
from .state import UserState
from .action import UserAction

class Policy(ABC):
    """决策策略抽象基类"""
    
    @abstractmethod
    def predict_action(self, state: UserState) -> UserAction:
        """根据当前状态预测用户动作
        Args:
            state: 当前用户状态
        
        Returns:
            预测的用户动作
        """
        raise NotImplementedError

    def update_policy(self, feedback: Dict[str, Any]) -> None:
        """策略更新方法（可选实现）
        Args:
            feedback: 策略反馈数据
        """
        pass  # 默认不实现