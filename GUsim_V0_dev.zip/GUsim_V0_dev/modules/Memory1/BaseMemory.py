"""
Author: LYZ
Date: 2025-03-23
Description: BaseMemory.py
"""


from abc import ABC, abstractmethod
from typing import Dict, List
import os
import sys
sys.path[0] = os.path.join(os.path.dirname(__file__), '..', '..')
from core import BaseMemory


class ExplicitMemory(BaseMemory):
    """
    Explicit memory indicates the methods that represent memory contents with texts.
    """
    def __init__(self, config) -> None:
        super().__init__(config)
    
    @abstractmethod
    def reset(self) -> None:
        pass

    @abstractmethod
    def store(self, observation) -> None:
        pass
    
    @abstractmethod
    def recall(self, query) -> str:
        pass

    @abstractmethod
    def display(self) -> None:
        pass
    
    @abstractmethod
    def manage(self, operation, **kwargs) -> None:
        pass
    
    @abstractmethod
    def optimize(self, **kwargs) -> None:
        pass


if __name__ == "__main__":
    print("Test!")