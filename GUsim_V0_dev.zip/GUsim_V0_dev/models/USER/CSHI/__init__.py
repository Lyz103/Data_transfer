# __init__
# -*- coding: utf-8 -*-
# @Author : LuyuChen
# @Time : 2024/10/19 20:09
import os
import sys
sys.path[0] = os.path.join(os.path.dirname(__file__), '..', '..')
from models.USER.CSHI.agent import CSHI_user
