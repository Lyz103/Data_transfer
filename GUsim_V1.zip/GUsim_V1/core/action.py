"""
Author: LYZ
Date: 2025-03-24
Description: action.py
"""

# core/action.py
from dataclasses import dataclass
from typing import Any

@dataclass
class UserAction:
    """用户动作基类"""
    type: str       # 动作类型（如：text, click, rating）
    content: Any    # 动作内容（文本/评分/元数据）
    metadata: dict = None  # 扩展字段（可选）

    def __post_init__(self):
        self.metadata = self.metadata or {}

