"""
Author: LYZ
Date: 2025-03-24
Description: core/simulator.py
"""


# core/simulator.py
from abc import ABC, abstractmethod
from typing import Any, List
from .memory import BaseMemory
from .state import UserState
from .action import UserAction
from .policy import Policy


class UserSimulator(ABC):
    """用户模拟器抽象基类"""
    
    def __init__(self, memory: List[BaseMemory], policy: Policy):
        self.memories = memory
        self.policy = policy
        self._current_state: UserState = None

    @abstractmethod
    def step(self, system_response: Any) -> UserAction:
        """执行单步交互
        Args:
            system_response: 系统返回的响应
        
        Returns:
            用户动作
        """
        raise NotImplementedError

    @abstractmethod
    def reset(self) -> None:
        """重置模拟器状态"""
        self._current_state = None
        self.memory = None  # type: ignore
        self.policy = None  # type: ignore

    def get_state(self) -> UserState:
        """获取当前用户状态"""
        if self._current_state is None:
            self._current_state = self.memory.recall()
        return self._current_state