# core/state.py
from dataclasses import dataclass
from typing import Dict, List

@dataclass
class UserState:
    """用户状态基类"""
    preferences: Dict[str, float]   # 用户偏好（物品/评分）
    conversation_history: List[str] # 对话历史记录
    current_intent: str             # 当前对话意图
    session_id: str = ""            # 会话标识（可选）