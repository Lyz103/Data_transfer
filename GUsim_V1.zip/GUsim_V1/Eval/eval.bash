export OPENAI_API_KEY="sk-G6XflAR04SvxaTl1QhmIl6HimueZ0ZPYFeEVD78gELMRqth5"
export OPENAI_BASE_URL="https://api.chatanywhere.tech"

python -u Evaluation.py > test2.log 2>&1