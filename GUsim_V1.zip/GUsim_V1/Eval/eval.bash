export OPENAI_API_KEY="sk-G6XflAR04SvxaTl1QhmIl6HimueZ0ZPYFeEVD78gELMRqth5"
export OPENAI_BASE_URL="https://api.chatanywhere.tech"

python -u Evaluation.py > "./res/test1.log" 2>&1



# python -u Evaluation_1v1.py > "test.log" 2>&1
# echo finish!
