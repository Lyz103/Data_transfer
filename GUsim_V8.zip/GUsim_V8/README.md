# 用户模拟器

```
src
├── EXP --实验相关(useless)
├── Eval --实验相关(useless)
├── Memory --记忆存储profile和上下文
├── Prompts
    ├── Prompts_ma.py --关键的两个prompt (hands make)
    ├── __init__.py
    ├── action_prompts.py --为了实现可控制，手动制定的动作
    ├── high_control_prompts.py --为了实现不回答和答非所问实现的高层次控制
    ├── style_prompts.py -- 风格控制相关prompt
    ├── meta_prompt.py -- 为了快速生成prompt的prompt
    └── Prompts_ma-meta.py --关键的两个prompt (生成的)

├── config -- 配置文件
    ├── Config.py --控制垂域
    ├── Evaluation_config.py --控制测试(实验相关)
    ├── LLM_config.py --控制LLM_action和LLM_chat的版本(推荐action用4.1-mini，回复用deepseek-reasoner)
    ├── Memory_config.py --控制记忆(基本用不上)
├── data --多轮对话存储的地方
├── datatypes.py --数据结构
├── evaluator --对对话pairwise和pointwise测评
├── main.py -- 主函数，从这里调用Simulator
├── models -- 其他的一些模拟器代码和CRS代码
├── plot.py -- 实验相关
├── profiles -- 关键，存储不同行为的profiles
├── run.bash -- 运行脚本
├── user_simulator.py -- 纯用户模拟器，不含log，跑批次用
└── utils -- 辅助函数
```

## 流程
1. 准备好profile  
2. 调用模拟器的action部分，生成开放的action
3. 调用模拟器的response部分，通过上一步生成的开放的action指导回复
4. 多轮对话保存，评测结果


![](./assets/GUSIM.png)

## 动作控制
对应于src/Prompts/action_prompts.py中的每个动作

---

### 🧠 对话行为指令分类表(手动控制)

| 编号 | 指令名称 | 带含义说明的表达式 | 用途说明 |
|------|-----------|---------------------|----------|
| 1 | `no_response` | `[no_res]` | 表示不回应或跳过当前回复 |
| 2 | `no_response_with_reason` | `""" """`（空内容） | 留空，表示“不回应” |
| 3 | `new_topic` | `[开启新的推荐话题]` | 主动切换到一个新的话题（如从电脑换到手机） |
| 4 | `new_topic_with_reason` | ``` 我想开启一个新的推荐话题，因为当前话题不再适合继续讨论。例如：如果在推荐电脑就换为推荐手机，如果推荐手机就换为推荐电脑。``` | 明确说明切换话题的原因和逻辑 |
| 5 | `accept_recommendation` | `[接受推荐]` | 接受对方或系统给出的推荐项 |
| 6 | `accept_recommendation_reason_with_reason` | ``` 我接受这个推荐，因为它符合我的兴趣和需求。``` | 解释为何接受推荐 |
| 7 | `ask_recommendation_reason` | `[询问推荐理由]` | 向对方/系统请求解释推荐的理由 |
| 8 | `ask_recommendation_reason_with_reason` | ``` 我想了解推荐的理由，以便更好地评估它是否适合我。``` | 表明为什么要问推荐理由 |
| 9 | `new_preference` | `[提出新的偏好]` | 提出新的个人偏好以优化推荐结果 |
| 10 | `new_preference_with_reason` | ``` 我想提出新的对当前推荐的产品的偏好,来让推荐系统的推荐更加符合我的需求。``` | 说明提出偏好的目的 |

询问产品细节用户模拟器天然实现  
每一个动作都对应着Profiles文件中的一份profile

---


## 回复风格控制
---

### 📝 语言表达风格分类汇总（非空项）

| 编号 | 风格维度             | 等级 | 描述关键词                         | 示例语句                                                                 |
|------|----------------------|------|------------------------------------|--------------------------------------------------------------------------|
| 1    | **正式程度 (Formality)**      | +1   | 正式、规范、书面化、礼貌           | “请提供相关信息。”、“请您确认以下内容。”                                 |
|      |                      | -1   | 非正式、口语化、亲切、俚语         | “有没有什么好吃的推荐？”、“这事儿你怎么看？”                             |
| 2    | **简洁程度 (Conciseness)**     | +1   | 简短、精炼、言简意赅               | “好。”、“嗯。”、“不太行。”                                               |
|      |                      | 0    | 中等长度、自然、信息适中           | “这个我也觉得不错。”、“你吃过这家吗？”                                   |
|      |                      | -1   | 冗长、修饰词多、情绪描述丰富       | “我现在真的特别饿了……有推荐的吗？”                                       |
| 3    | **情感倾向 (Sentiment)**       | +1   | 积极、热情、乐观、鼓励             | “太棒了！”、“我非常喜欢你的想法！”                                       |
|      |                      | 0    | 中性、客观、理性                   | “这是事实。”、“我们可以考虑一下。”                                        |
|      |                      | -1   | 消极、不满、失望、批评             | “这真是太糟糕了。”、“我真的无法接受这种安排。”                           |
| 4    | **主动性 (Proactiveness)**     | +1   | 主动发起话题、引导对话、推动交流   | “你觉得这个方案怎么样？”、“我有个想法，想和你讨论一下。”                 |
|      |                      | -1   | 被动回应、较少主动推进对话         | “好的，明白了。”、“那我们就这样吧。”                                     |
| 5    | **随意程度 (Carelessness)**    | +1   | 随意、打字错误、用词不准确         | 把“饺子”写成“教资”，出现拼写或语法错误                                   |
| 6    | **表情符号使用 (Emojis)**      | +1   | 喜欢频繁使用表情符号强化情绪       | “😂🤣👀”、“🫠🥲”、“😤👊💥”                                              |
| 7    | <mark style="background-color: green;">**急躁程度 (Impatience)** </mark>     | +1   | 不耐烦、催促、焦躁、急切语气       | “快点吧，别磨蹭了。”、“能不能快点儿？我真的没时间等。”                   |
| 8    | <mark style="background-color: green;">**模糊程度 (Vague)** </mark>            | +1   | 含糊不清、模棱两可、回避明确表态   | “好像是吧……不太确定。”、“大概……应该可以吧。”                            |

---

📌 **说明：**
- 表中的风格控制和src/Prompts/style_prompts.py 相关
- 每个维度都可能有多个等级（+1, 0, -1），但部分等级未提供内容（如 `formality_0`、`emojis_0` 等， LLM自身天然实现），因此未在表中列出。


## 对用户模拟器本身进行评测
[点击查看 对用户模拟器评测 说明](./src/Eval/Readme.md)


## 对CRS的通用能力和鲁棒性测试
[点击查看 evaluator 说明](./src/evaluator/Readme.md)






## 运行pipeline

1. 安装环境
```
conda create -n Usim python=3.10
conda activate Usim
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```
2. 设置api-key (run.bash)
```bash
export OPENAI_API_KEY="sk-xxx"
export OPENAI_BASE_URL=""
```

3. 运行代码
```
bash run.bash
```

4. 更换不同的profile: main.py第352行


## 注意
如果在公司电脑上跑，可能会
1. 出现linux->windows编码问题, 只需要设定编码为utf-8即可
2. 调用LLM时出现SSL报错，只需要在OpenAI服务器指代verify=False
3. 本代码只在LLM作为Backbone的BaseCRS上进行过调试，所以在真实场景下有问题是不可避免的，需要调节prompt来解决问题
4. 更多的想要模拟的，可以根据前面的方法写prompt直接进行控制
