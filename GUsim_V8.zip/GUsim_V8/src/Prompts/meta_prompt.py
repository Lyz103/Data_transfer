import jinja2
from jinja2 import Template
import os
import sys
from openai import OpenAI

class LLM_call:
    def __init__(self, llm_model=None):
        self.llm_model = llm_model

    def call_llm(self, llm_input):
        raise NotImplementedError

    def __call__(self, llm_input):
        return self.call_llm(llm_input)


class OPENAI_call(LLM_call):
    def __init__(self, llm_model=None):
        super(OPENAI_call, self).__init__(llm_model)
        self.model = llm_model
        self.temperature = 0
        self.max_tokens = 512
        self.seed = 39
        self.client = OpenAI()


    # @retry(stop_max_attempt_number=10)
    def call_llm(self, llm_input):
        # try:
        # print("self.model:", self.model)
        output = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": llm_input}
            ],
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            seed=self.seed
        )
        # print(output)

        return output.choices[0].message.content
        # except Exception as e:
        #     LOGGER.warning(f"Failed to call LLM model: {e}")
        #     return None

    def set_temperature(self, temperature):
        self.temperature = temperature

    def set_max_tokens(self, max_tokens):
        self.max_tokens = max_tokens

    def set_seed(self, seed: int):
        self.seed = seed


meta_info_vmall = {
    'domain_sys': '虚拟商店推荐系统',
    'domain_specific':[
    'categoryNot',
    'deviceNot',
    'seriesNot',
    'colorNot',
    'minPrice',
    'maxPrice',
    ],
    'context':[
    'category',
    'device',
    'series',
    'color',
    'configuration',
    'sorting',
    'scene',
    'fuction'
    ]
}

meta_info_food = {
    'domain_sys': '美食推荐系统',
    'domain_specific':[
    'locationNot',
    'tasteNot',
    'shopNot',
    'constraint',
    'time',
    'taste',
    'location',
    'listType',
    'scenes',],
    'context':[
    'price',
    'rating',
    'privateRoom',
    'radius',
    'sourceLocation',
    'targetLocation'
]
}

meta_info_Beauty = {
    'domain_sys': '美妆推荐系统',
    'domain_specific':[
    "skinType",
    "skinProblem",
    "environmentalFactors",
    "lifestyleHabits",
    "ContraindicatedIngredients",
    "AvoidBranding",
    "priceRange",
    "purchasedProducts",],
    'context':[
    "productType",
    "focusOnEfficacy",
    "SkincareScene",
    "SkincareTime",
    "ingredientPreference",
    "brandPreference",
    "compareDimensions",
    "OfferedProducts"]
}

TEST_PROMPT = """
你是一个Prompt工程师，任务是根据给定的推荐系统领域和相关字段信息，生成一段用于构建用户画像（Profile）的Prompt模板。

模板的目标是：根据字段信息自动生成一段自然语言，用于表达用户的偏好、不感兴趣项、上下文信息及其他约束条件，以支持推荐系统的用户建模阶段。

以下是一个示例：

{% raw %}
输入：
    'domain_sys': '美食推荐系统',
    'domain_specific': [
        'locationNot',
        'tasteNot',
        'shopNot',
        'constraint',
        'time',
        'taste',
        'location',
        'listType',
        'scenes'
    ],
    'context': [
        'price',
        'rating',
        'privateRoom',
        'radius',
        'sourceLocation',
        'targetLocation'
    ]

输出：
```jinja2
{% if domain_sys == "美食推荐系统" %}
你不想去的用餐地点是{{ locationNot }}，不感兴趣的口味是{{ tasteNot }}，不考虑的店铺有{{ shopNot }}，你的其他用餐限制为：{{ constraint }}。

当前情境如下：
{% if time %}现在的时间是：{{ time }}，{% endif %}
{% if taste %}你喜欢的口味是：{{ taste }}，{% endif %}
{% if location %}你希望用餐的地点是：{{ location }}。{% endif %}
{% if listType %}你关注的榜单类型为：{{ listType }}。{% endif %}
{% if scenes %}你的用餐场景是：{{ scenes }}。{% endif %}

你对餐厅的具体要求包括：
{% if price %}人均消费范围：{{ price }}。{% endif %}
{% if rating %}餐厅评分不低于：{{ rating }}。{% endif %}
{% if privateRoom %}是否需要包间：{{ privateRoom }}。{% endif %}
{% if radius %}距离限制为：{{ radius }}。{% endif %}
{% if sourceLocation and targetLocation %}从{{ sourceLocation }}前往{{ targetLocation }}的途中推荐。{% endif %}

如果这是对话的第一轮，请在满足上述条件的前提下推荐合适的餐厅。
{% endif %}
```
{% endraw %}

现在请根据以下输入字段，生成一段用于美妆推荐系统的Profile Prompt模板：
注意美妆推荐系统是推荐化妆品、护肤品等，请根据输入字段生成一段用于美妆推荐系统的Profile Prompt模板。
输入：
'domain_sys': '美妆推荐系统',
    'domain_specific':[
        "skinType",
        "skinProblem",
        "environmentalFactors",
        "lifestyleHabits",
        "ContraindicatedIngredients",
        "AvoidBranding",
        "priceRange",
        "purchasedProducts",
        ],
    'context':[
        "productType",
        "focusOnEfficacy",
        "SkincareScene",
        "SkincareTime",
        "ingredientPreference",
        "brandPreference",
        "compareDimensions",
        "OfferedProducts"
        ]
输出：
```jinja2
<你的输出>
```
"""




RESPONSE = Template(TEST_PROMPT)

print(RESPONSE.render())

llm_model = OPENAI_call(llm_model="gpt-4o-ca")
print(llm_model(RESPONSE.render()))
