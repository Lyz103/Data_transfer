no_response = "[no_res]"
no_response_with_reason = """

"""

new_topic = "[开启新的推荐话题]"

new_topic_with_reason = """
我想开启一个新的推荐话题，因为当前话题不再适合继续讨论。如果在推荐电脑就换为推荐手机，如果推荐手机就换为推荐电脑。
"""

accept_recommendation = "[接受推荐]"

accept_recommendation_with_reason = """
我想接受推荐，因为它符合我的兴趣和需求。
"""


ask_recommendation_reason = "[询问推荐理由]"

ask_recommendation_reason_with_reason = """
我想了解推荐的理由，以便更好地评估它是否适合我。
"""

new_preference = "[提出新的偏好]"

new_preference_with_reason = """
我想提出新的对当前推荐的产品的偏好,来让推荐系统的推荐更加符合我的需求。
"""



