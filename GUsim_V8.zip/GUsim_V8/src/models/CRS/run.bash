export OPENAI_API_KEY="sk-sk-xxx"
export OPENAI_BASE_URL="https://api.chatanywhere.tech"

python -u AgentCRS.py > log.log 2>&1