export OPENAI_API_KEY="sk-xxx5"
export OPENAI_BASE_URL="https://api.chatanywhere.tech"



python -u eval_pairwise_rob.py > "result_rob/gpt-3.5_agent.log" 2>&1
# echo finish!
