export OPENAI_API_KEY="sk-xxx"
export OPENAI_BASE_URL="https://api.chatanywhere.tech"



python -u eval_common_pairwise.py > "result/eval_common_pairwiseA4ominiVSA3.5_Ugpt-4.1-mini2.log" 2>&1
# echo finish!
