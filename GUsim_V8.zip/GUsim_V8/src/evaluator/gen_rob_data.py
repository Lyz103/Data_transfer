# Typo
# Drop
# Shuffle
# common

import jieba
import os
import sys
import copy
import json
import random
sys.path[0] = os.path.join(os.path.dirname(__file__), '..')
from utils import OPENAI_call

from config.Config import Simulator_Config
from user_simulator import UserSimulator
from models.CRS import GptBasedCRS, AgentCRS
from collections import deque
cfg = Simulator_Config()
llm = OPENAI_call("deepseek-reasoner")


def extract_keywords(sentence):
    prompt = f"""你是一个美食推荐领域的专家，请你帮我提取出以下句子中的关键词，关键词之间用逗号分隔。请确保关键词是中文，并且不要包含任何其他标点符号或空格。
    "{sentence}" """

    keywords_str = llm(prompt).strip()
    keywords = [kw.strip() for kw in keywords_str.replace("，", ",").split(",") if kw.strip()]
    return keywords

def drop_one_keyword(sentence):
    keywords = extract_keywords(sentence)
    if not keywords:
        return sentence  # 没关键词则不变

    # 如果关键词数量小于3，则最多丢弃 len(keywords) 个
    num_to_drop = min(3, len(keywords))
    keywords_to_drop = random.sample(keywords, num_to_drop)

    # 依次删除这些关键词
    disturbed_sentence = sentence
    for kw in keywords_to_drop:
        disturbed_sentence = disturbed_sentence.replace(kw, "")

    return disturbed_sentence.strip()


def shuffle_words(sentence, seed=None):
    if seed is not None:
        random.seed(seed)
        
    # 分词
    words = list(jieba.cut(sentence))
    
    # 打乱词序
    shuffled = words[:]
    random.shuffle(shuffled)
    
    # 拼回句子
    disturbed_sentence = ''.join(shuffled)
    
    return disturbed_sentence  # 返回原词序用于对比


def generate_typo(sentence):
    prompt = f"""你是一个推荐系统和语言学的专家。请将下面这句中文模拟一个真实的人类输入时可能出现的拼写错误版本。保留大致语义，但用形近字、音近字、拼音错误、选字错误等方式错几个字：
    “{sentence}” 
    请在推荐的关键词上施加错误。
    比如：给我推荐点饺子 -> 给我来点教资

    只输出打错后的句子，不加说明。"""

    
    return llm(prompt).strip()


import json
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

lock = threading.Lock()

def Gen_data(profile, filename, i):
    try:
        to_save = []
        usersimulator = UserSimulator(profile, config=cfg)

        user_chat, _, _ = usersimulator.interact(1)
        typo_sentence = generate_typo(user_chat)
        drop_sentence = drop_one_keyword(user_chat)
        shuffle_sentence = shuffle_words(user_chat)
        original_sentence = user_chat
        sentence_dict = {
            "original": original_sentence,
            "typo": typo_sentence,
            "drop": drop_sentence,
            "shuffle": shuffle_sentence
        }

        for sentence_type, sentence in sentence_dict.items():
            crs1 = AgentCRS(model="gpt-3.5-turbo")
            crs2 = AgentCRS(model="gpt-4o-mini")

            crs1_res = crs1.interact(sentence)
            crs2_res = crs2.interact(sentence)
            to_save.append({
                "id": i,
                "sentence_type": sentence_type,
                "sentence": sentence,
                "crs1_response": crs1_res,
                "crs2_response": crs2_res
            })

        # 使用锁写入文件，避免并发冲突
        with lock:
            with open(filename, "a", encoding="utf-8") as f:
                for entry in to_save:
                    f.write(json.dumps(entry, ensure_ascii=False, indent=4) + "\n")

        return True

    except Exception as e:
        print(f"Error processing profile {i}: {e}")
        return False


if __name__ == "__main__":
    filename = "robustness_data_agent_crs.jsonl"
    profiles = []
    with open("synthesized_profiles.jsonl", 'r', encoding="utf-8") as f:
        for line in f:
            profiles.append(str(line))

    # 控制并发次数，例如最大8个线程
    max_workers = 8

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = []
        for j in range(3):
            for i, profile in enumerate(profiles):
                futures.append(executor.submit(Gen_data, profile, filename, i))

        # 等待所有任务完成
        for future in as_completed(futures):
            future.result()