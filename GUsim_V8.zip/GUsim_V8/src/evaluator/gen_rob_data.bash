export OPENAI_API_KEY="sk-xxx"
export OPENAI_BASE_URL="https://api.chatanywhere.tech"



python -u gen_rob_data.py > "Base.log" 2>&1
# echo finish!
