export OPENAI_API_KEY="sk-xxx"
export OPENAI_BASE_URL="https://api.chatanywhere.tech"



python -u BFS.py > "BFS_AVSA3.log" 2>&1
# echo finish!
