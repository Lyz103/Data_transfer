## 目录

evaluator/
├── BFS.bash                 # 启动脚本，用于运行 BFS.py
├── BFS.py                   # 使用 BFS 生成数据，保持两个 CRS 上下文一致
├── Readme.md                # 本目录说明文件
├── data_process.ipynb       # 数据处理 Jupyter Notebook
├── eval_common_pairwise.py  # 通用能力的 pairwise 对比脚本
├── eval_pairwise.bash       # 启动 eval_common_pairwise.py 的脚本
├── eval_pairwise_rob.bash   # 启动 eval_pairwise_rob.py 的脚本
├── eval_pairwise_rob.py     # 对 CRS 鲁棒性进行 pairwise 对比
├── eval_prompts.py          # 通用测试 prompt
├── eval_rob_prompts.py      # 鲁棒性测试 prompt
├── gen_rob_data.bash        # 启动 gen_rob_data.py 的脚本
├── gen_rob_data.py          # 生成鲁棒性测试数据
├── pearson.ipynb            # 皮尔逊相关性分析 Notebook
└── synthesized_profiles.jsonl  # 合成用户画像数据（JSON Lines 格式）



### 为什么采用 Pairwise 评估方式？
1. **避免细粒度评分误差**：在实际数据中，某些样本的真实分数是连续的（如 3.23），但我们在打分时通常采用固定间隔（例如 0.5 分）进行离散化评分，最终可能被标注为 3 分或 3.5 分，导致细粒度误差的引入。
2. **LLM 高情商偏差**：大语言模型（LLM）在经过微调后往往表现得更加“高情商”，即对模型输出更宽容，容易给出偏高的评分。例如，原本应得 3.23 分的样本可能被打成 4 分甚至更高，从而掩盖了模型之间在细节上的差异。
3. **Pairwise 更具区分能力**：采用 pairwise 比较方式，即使面对两个非常接近的样本（如 3.23 vs 3.30），模型也有可能在排序中体现出偏好，从而更好地区分性能优劣。这种方法在相对判断上比绝对评分更敏感、更稳定。

