import os
import sys
import json
import re
import random
sys.path[0] = os.path.join(os.path.dirname(__file__), '..')
from utils import OPENAI_call
from evaluator.eval_rob_prompts import language, recommendation, action, evaluator_prompt
data_save_path = "/data/liyuanzi/HUAWEI/GUsim_V5/src/evaluator/result_rob/res_3.5_agent.jsonl"

import json

def read_json_objects(file_path):
    buffer = ''
    with open(file_path, 'r', encoding='utf-8') as f:
        datas = []
        for line in f:
            buffer += line.strip()
            try:
                # 尝试解析当前 buffer 中的内容
                obj = json.loads(buffer)
                # yield obj
                datas.append(obj)
                buffer = ''  # 成功解析后清空 buffer
            except json.JSONDecodeError:
                # 如果还没解析成功，继续拼接
                continue
        return datas


def data_process(data_path):
    datas = []
    utterances = []
    profiles = []
    datas = read_json_objects(data_path)
    datas = datas[0:800]
    ori = datas[0::4]
    typo = datas[1::4]
    drop = datas[2::4]
    shuffle = datas[3::4]
            


        
    
    return ori, typo, drop, shuffle


def eval(ori, typo, drop, shuffle, llm_judge):
    results = []
    robs = [typo, drop, shuffle]

    results = [[], [], []]
    rob = ["Typo", "Drop", "Shuffle"]
    for i in range(len(ori)):
        _, _ , history, _, ori_res = ori[i].values() 

        for j in range(len(robs)): 
            print(rob[j])
            _, _ , _, _, rob_res = robs[j][i].values() 

            for k in [1, -1]:
                input_message = {}
                input_message.update({"context": history})
                input_message.update({"language": language, "recommendation": recommendation, "action": action})
                if k == 1:
                    input_message.update({"CRS1_reply": ori_res, "CRS2_reply": rob_res})
                else:
                    input_message.update({"CRS1_reply": rob_res, "CRS2_reply": ori_res})
                prompt = evaluator_prompt.render(input_message)
                # print(f"Evaluating dialogue {i+1} with prompt:\n{prompt}\n")
                
                result = llm_judge(prompt)
                # print(f"Dialogue {i+1} evaluation result:\n{result}\n")
                # 匹配评分数字

                naturalness_score = re.search(r'\[naturalness\](-?\d+)\[/naturalness\]', result)
                recommendation_score = re.search(r'\[recommendation\](-?\d+)\[/recommendation\]', result)
                understandability_score = re.search(r'\[understandability\](-?\d+)\[/understandability\]', result)

                # 提取并打印结果
                scores = {
                    "tag": k,
                    "naturalness": naturalness_score.group(1) if naturalness_score else None,
                    "recommendation": recommendation_score.group(1) if recommendation_score else None,
                    "understandability": understandability_score.group(1) if understandability_score else None
                }
                scores1 = {
                    "rob": rob[j],
                    "tag": k,
                    "naturalness": naturalness_score.group(1) if naturalness_score else None,
                    "recommendation": recommendation_score.group(1) if recommendation_score else None,
                    "understandability": understandability_score.group(1) if understandability_score else None
                }
                with open(data_save_path, 'a', encoding='utf-8') as f:
                    json.dump(scores1, f, ensure_ascii=False)
                    f.write('\n')
                results[j].append(scores)
                print(f"Dialogue {i+1} Scores: {scores}")

    return results


def main():
    pass

# 单个文件的处理函数
def process_file():
    # try:
    print(f"Processing data file...")
    data_path = f"/data/liyuanzi/HUAWEI/GUsim_V5/src/evaluator/robustness_data_agent_crs.jsonl"
    if not os.path.exists(data_path):
        raise FileNotFoundError(f"File not found: {data_path}")

    llm_judge = OPENAI_call("gpt-4o-ca")
    ori, typo, drop, shuffle = data_process(data_path)
    # utterances = random.sample(utterances, min(5, len(utterances)))  # 防止不足5条时报错

    eval_results = eval(ori, typo, drop, shuffle, llm_judge)
    print(f"eval_results: {eval_results}")
    return eval_results
    # except Exception as e:
    #     print(f"Error processing data file {i}: {e}")
    #     return []

# from concurrent.futures import ThreadPoolExecutor, as_completed
# # 主函数：并发执行多个文件处理
# def run_parallel_processing():
#     sum_eval_results = []

#     with ThreadPoolExecutor(max_workers=1) as executor:  # 可根据实际情况调整 max_workers
#         futures = [executor.submit(process_file, i) for i in range(40)]

#         for future in as_completed(futures):
#             result = future.result()
#             sum_eval_results.extend(result)

#     print("All evaluation results collected:", len(sum_eval_results))
#     return sum_eval_results


if __name__ == "__main__":

    # sum_eval_results = []
#     for i in range(40):
#         try:
#             print(f"Processing data file {i}...")
#             data_path = f"/data/liyuanzi/HUAWEI/GUsim_V5/src/evaluator/eval_data/B4ominiVSB3.5_Ugpt-4o-mini/output{i}.jsonl"
#             print("data_path", data_path)
#             llm_judge = OPENAI_call("gpt-4o-ca")
#             utterances, profile = data_process(data_path, i)
#             utterances = random.sample(utterances, 5)

#             print("utterances:", len(utterances))
#             print("profile:", profile)
#             eval_results = eval(utterances, profile, llm_judge)

#             print("eval_results:", eval_results)
#             sum_eval_results.extend(eval_results)
#         except Exception as e:
#             print(f"Error processing data file {i}: {e}")
#             continue
# final_results = 
    eval_resultss = process_file()
    # Count occurrences of 1, 0, and -1 for each score type
    for i in range(len(eval_resultss)):
        if i == 0: print("Typo\n" + "*" * 20)
        elif i == 1: print("Drop\n" + "*" * 20)
        elif i == 2: print("Shuffle\n" + "*" * 20)
        eval_results = eval_resultss[i]
        score_counts = {
            "understandability": {"1": 0, "0": 0, "-1": 0},
            "naturalness": {"1": 0, "0": 0, "-1": 0},
            "recommendation": {"1": 0, "0": 0, "-1": 0},
        }
        # 统计各个评分的数量
        for res in eval_results:
            for key in score_counts:
                val = res.get(key, None)
                tag = res.get("tag", None)
                if val in ["1", "0", "-1"]:
                    if tag == 1:
                        score_counts[key][val] += 1
                    elif tag == -1:
                        # 如果tag为-1，则交换评分
                        if val == "1":
                            score_counts[key]["-1"] += 1
                        elif val == "0":
                            score_counts[key]["0"] += 1
                        elif val == "-1":
                            score_counts[key]["1"] += 1

        # 计算平均分
        total = len(eval_results)

        understandability_score1 = score_counts["understandability"]["1"] / total * 100
        understandability_score0 = score_counts["understandability"]["0"] / total * 100
        understandability_scoref1 = score_counts["understandability"]["-1"] / total * 100

        naturalness_score1 = score_counts["naturalness"]["1"] / total * 100
        naturalness_score0 = score_counts["naturalness"]["0"] / total * 100
        naturalness_scoref1 = score_counts["naturalness"]["-1"] / total * 100

        recommendation_score1 = score_counts["recommendation"]["1"] / total * 100
        recommendation_score0 = score_counts["recommendation"]["0"] / total * 100
        recommendation_scoref1 = score_counts["recommendation"]["-1"] / total * 100

        # 打印结果
        print("Understandability Scores:")
        print(f"  Score 1: {understandability_score1:.1f}")
        print(f"  Score 0: {understandability_score0:.1f}")
        print(f"  Score -1: {understandability_scoref1:.1f}")

        print("\nNaturalness Scores:")
        print(f"  Score 1: {naturalness_score1:.1f}")
        print(f"  Score 0: {naturalness_score0:.1f}")
        print(f"  Score -1: {naturalness_scoref1:.1f}")

        print("\nRecommendation Scores:")
        print(f"  Score 1: {recommendation_score1:.1f}")
        print(f"  Score 0: {recommendation_score0:.1f}")
        print(f"  Score -1: {recommendation_scoref1:.1f}")

