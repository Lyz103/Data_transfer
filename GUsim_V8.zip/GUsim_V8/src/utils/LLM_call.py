from openai import OpenAI
import logging
# import torch
# from transformers import AutoModelForCausalLM, AutoTokenizer
import os
from retrying import retry

LOGGER = logging.getLogger("UserSimulator")
# GLM_DIR = os.path.join(os.path.dirname(__file__), "../../models/glm-4-9b-chat")

class LLM_call:
    def __init__(self, llm_model=None):
        self.llm_model = llm_model

    def call_llm(self, llm_input):
        raise NotImplementedError

    def __call__(self, llm_input):
        return self.call_llm(llm_input)


class OPENAI_call(LLM_call):
    def __init__(self, llm_model=None):
        super(OPENAI_call, self).__init__(llm_model)
        self.model = llm_model
        self.temperature = 0
        self.max_tokens = 512
        self.seed = 39
        self.client = OpenAI()


    # @retry(stop_max_attempt_number=10)
    def call_llm(self, llm_input):
        # try:
        # print("self.model:", self.model)
        output = self.client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": llm_input}
            ],
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            seed=self.seed
        )
        # print(output)

        return output.choices[0].message.content
        # except Exception as e:
        #     LOGGER.warning(f"Failed to call LLM model: {e}")
        #     return None

    def set_temperature(self, temperature):
        self.temperature = temperature

    def set_max_tokens(self, max_tokens):
        self.max_tokens = max_tokens

    def set_seed(self, seed: int):
        self.seed = seed


class Qwen_call(LLM_call):
    def __init__(self, llm_model=None):
        super(Qwen_call, self).__init__(llm_model)
        self.model = llm_model
        self.temperature = 0
        self.max_tokens = 512
        self.seed = 39
        self.enable_thinking = False
        self.client = OpenAI(base_url="http://localhost:8092/v1", api_key="qwen-fxy")  # qwen-fxy 随便填写，只是为了通过接口参数校验


    # @retry(stop_max_attempt_number=10)
    def call_llm(self, llm_input):
        # try:
        # print("self.model:", self.model)
        output = self.client.chat.completions.create(
            model=self.model,
            extra_body={
            "chat_template_kwargs": {"enable_thinking": self.enable_thinking},
            },
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": llm_input}
            ],
            temperature=self.temperature,
            max_tokens=self.max_tokens,
            seed=self.seed
        )
        # print(output)

        return output.choices[0].message.content
        # except Exception as e:
        #     LOGGER.warning(f"Failed to call LLM model: {e}")
        #     return None

    def set_temperature(self, temperature):
        self.temperature = temperature

    def set_max_tokens(self, max_tokens):
        self.max_tokens = max_tokens

    def set_seed(self, seed: int):
        self.seed = seed
    
    def set_thinking(self, enable_thinking: bool):
        self.enable_thinking = enable_thinking



# if __name__ == "__main__":
#     import os
#     os.environ["OPENAI_BASE_URL"] = "https://api.chatanywhere.tech"

#     os.environ["OPENAI_API_KEY"] = "sk-sk-xxx"
#     # openai.api_base = "https://api.chatanywhere.tech"
#     llm_call = OPENAI_call("deepseek-r1")
#     print(llm_call("Hello, how are you?"))

