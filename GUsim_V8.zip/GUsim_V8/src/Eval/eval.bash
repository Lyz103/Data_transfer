export OPENAI_API_KEY="sk-xxx"
export OPENAI_BASE_URL="https://api.chatanywhere.tech"
# python -u Evaluation.py > "./res/test2.log" 2>&1



python -u Evaluation_fast.py > "meta.log" 2>&1
# echo finish!
