## 目录

Eval
├── Evaluation.py -- 对用户模拟器的测评，pairwise， 两边随机挑一个
├── Evaluation_1v1.py -- 对用户模拟器的测评，pairwise，相同的profile的对比
├── Evaluation_fast.py -- 对用户模拟器的测评，pairwise，相同的profile的对比(多线程加速)
├── Metrics.py
├── __pycache__
├── eval.bash
├── prompts
└── readme.md