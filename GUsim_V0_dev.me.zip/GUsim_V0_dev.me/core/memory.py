"""
Author: LYZ
Date: 2025-03-24
Description: memory.py
"""
# core/memory.py
from abc import ABC, abstractmethod
from typing import Dict, List

class BaseMemory(ABC):
    """
    Basic class for memory methods.
    """
    def __init__(self, config) -> None:
        self.config = config

    def __reset_objects__(self, objects):
        for obj in objects:
            obj.reset()

    @abstractmethod
    def reset(self) -> None:
        pass

    @abstractmethod
    def store(self, obj) -> None:
        pass
    
    @abstractmethod
    def recall(self, obj) -> object:
        pass
    
    @abstractmethod
    def manage(self, operation, **kwargs) -> None:
        pass
    
    @abstractmethod
    def optimize(self, **kwargs) -> None:
        pass
