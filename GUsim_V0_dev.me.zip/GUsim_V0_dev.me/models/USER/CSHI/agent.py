# __init__
# -*- coding: utf-8 -*-
# @Author : LuyuChen
# @Time : 2024/10/19 19:43
import random

from datatypes import Agent
import openai
import os
import sys
sys.path[0] = os.path.join(os.path.dirname(__file__), '..', '..')
from models.USER.CSHI.user_sim_agent import UserSimV3

# if __name__ == "__main__":
#     openai.api_base = ""
#     openai.api_key = ""
#     user = UserSimV3()
#     user.reset(target_item="Mapo toufu", user_id=1)
#     reply = user.step("你好，有什么可以帮助你的吗？")
#     while True:
#         print(reply)
#         response = input(">>>")
#         reply = user.step(response)
#         if reply == "对话结束":
#             break

class CSHI_user(Agent):
    def __init__(self, target_item: str, model_name="gpt-3.5-turbo", name="CSHIUser",
                 description="CSHI's user model"):
        super().__init__(name+"("+model_name+")", description)
        self.user = UserSimV3(model_name=model_name)
        self.user.reset(target_item, 1)
        self.target_item = target_item
        self.model_name = model_name

    def interact(self, str_input) -> str:

        if str_input is not None:
            response = self.user.step(str_input)
        else:
            response = self.user.step("你好，有什么可以帮助你的吗？")
        return response

    def clear_interaction_history(self):
        self.user.reset(self.target_item, 1)

    def get_profile(self):
        return {
            "target_item": self.target_item
        }

    def _call_llm(self, messages):
        response = openai.ChatCompletion.create(
            model=self.model_name,
            messages=messages
        )
        return response.choices[0].message["content"]

    def _get_random_item(self):
        prompt = """
        You are a seeker chatting with a recommender for food recommendation. 
        PLlease randomly choose a target item.
        Possible target items can be "饺子混沌", "汉堡薯条", "炸鸡炸串", "意面披萨", "包子粥店", "快餐便当", "米粉面馆", "麻辣烫冒菜"
        However, you can also provide your own target item.
        Please provide the target item using the following format:
        [item]str(in Chinese)[/item]
        """
        messages = [{"role": "system",
                     "content": prompt}]
        model = self.model_name
        self.model_name = "gpt-4o"
        response = self._call_llm(messages)
        self.model_name = model
        try:
            target_item = response.split("[item]")[1].split("[/item]")[0]
        except:
            target_item = random.choice(["饺子混沌", "汉堡薯条", "炸鸡炸串", "意面披萨", "包子粥店", "快餐便当", "米粉面馆", "麻辣烫冒菜"])
        return target_item

    def refresh_profile(self, target_item: str = None):
        if target_item is None:
            target_item = self._get_random_item()
        self.target_item = target_item


