import os
import sys
sys.path[0] = os.path.join(os.path.dirname(__file__), '..', '..')
from models.USER.CSHI.src.plugins import *
import os


class Plugin():
    def __init__(self):
        self.handlers = {}
    
    def load_config(self) -> dict:
        plugin_conf = PluginManager().get_plugin_config(self.name)
        return plugin_conf


    