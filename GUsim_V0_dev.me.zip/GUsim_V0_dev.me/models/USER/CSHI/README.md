# A LLM-based Controllable, Scalable, Human-Involved User Simulator Framework for Conversational Recommender Systems

### 📺Demo

---

#### CSHI-Based User Simulator

![](./assets/1.png)

![](./assets/2.png)

![](./assets/3.png)

#### Single-prompt User Simulator

![](./assets/4.png)